
/*
 * Author : KAJAMOHAN K. (2018/E/055)
 */

package com.os.replacementalgorithm;

public class ReplacementAlgorithm {

    public static void main(String[] args) {
        new MainFrame().setVisible(true);        
    }
}
